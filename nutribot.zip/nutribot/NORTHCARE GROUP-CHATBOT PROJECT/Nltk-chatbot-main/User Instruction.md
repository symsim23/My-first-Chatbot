Here are the steps to run the chatbot prototype in PyCharm Environment

    1.) Open PyCharm and create a new project.

    In the project interpreter, make sure that you have installed and imported the required packages: nltk, numpy, tensorflow, and tflearn and all others. If not, you can install them using pip in the terminal by typing:

    2.) pip install nltk numpy tensorflow tflearn.

    3.) Download the intents.json file and save it in the same directory as the Python code.
        or preferably extract the zip file in one location and access it from your pycharm development environment.

    4.) Run the Python file (train.py) in PyCharm and run it to train the model.
    5.) Run the python file NUTRIBOTAPP.PY which will use the Nutribot model to process interaction.

    Note: Run the code by clicking the green arrow icon in the top right corner of the PyCharm window or by pressing Shift + F10.

    The chatbot will then start running and will display the message "Welcome I am Nutribot with a disclaimer!" in the console.

    You can now test the chatbot by typing in some questions or phrases and seeing how it responds.
