#importing all the libraries needed
import nltk
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import json
import pickle
import numpy as np

from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.optimizers import SGD
import random

#creating empty lists to store "words" from pattern and store intent in "classes" and the pair of words and corresponding pattern in "documents"
words=[]
classes = []
documents = []
ignore_words = ['?', '!', ',']
data_file = open('intents.json').read()
#Open and read data json set
intents = json.loads(data_file)


# Preprocessing
#creating a nested loop to iterate through each intent(tag) and pattern in the dataset
for intent in intents['intents']:
    for pattern in intent['patterns']:

        #tokenize each word(splits texts into individual words)
        w = nltk.word_tokenize(pattern)
        #add tokenize words to the word list using extend function
        words.extend(w)
        #add tokenized pattern and their corresponding intent to the document list
        documents.append((w, intent['tag'])) 

        # add tokenized intent to our classes list, if the intent is not there
        if intent['tag'] not in classes:
            classes.append(intent['tag'])
 #Essentially after tokenization the loop collects all the words intent and pattern information from our data and store them in their respective list


# lemmatize(reduce words to their base form), lower each word and remove duplicates with the set function
words = [lemmatizer.lemmatize(w.lower()) for w in words if w not in ignore_words]
words = sorted(list(set(words)))
# sort classes
classes = sorted(list(set(classes)))
# documents = combination between patterns and intents
print (len(documents), "documents")
# classes = intents
print (len(classes), "classes", classes)
# words = all words, vocabulary
print (len(words), "unique lemmatized words", words)

#The preprocessed list of words and classes are now saved using the pickle module, which converts python objects to binary files.
pickle.dump(words,open('words.pkl','wb'))
pickle.dump(classes,open('classes.pkl','wb'))

# Create training data

# create an empty list that will collect training data for all pattern and intent
training = []
# create an empty array for our output
output_empty = [0] * len(classes)
# Create a loop over each item in the document list
for doc in documents:
    # create an empty list called bag which will hold the bag of words for the current pattern
    bag = []
    #tokenized words are retrived from the document list and then lemmatized
    pattern_words = doc[0]
    # lemmatize each word - create base word, in attempt to represent related words
    pattern_words = [lemmatizer.lemmatize(word.lower()) for word in pattern_words]
    # create our bag of words array with 1, if word match found in current pattern
    for w in words:
        bag.append(1) if w in pattern_words else bag.append(0)
#add bow and output row to the training list
    # output is a '0' for each tag and '1' for current tag (for each pattern)
    output_row = list(output_empty)
    output_row[classes.index(doc[1])] = 1

    training.append([bag, output_row])
# shuffle our features to randomize the order of pattern using random
random.shuffle(training)
training = np.array(training)
#convert training list to array using numpy
# create train and test lists. X - patterns, Y - intents
train_x = list(training[:,0])#bag of words representing the pattern
train_y = list(training[:,1])  #output row(one hot encoding) representing the intents
print("Training data created")
#Now we have successfully created a training data required to train neural network model.


# Build the model using Artificial Neural Network

# Create model - 3 layers. First layer 164 neurons, second layer 82 neurons and 3rd output layer contains number of neurons
# equal to number of intents to predict output intent with softmax
model = Sequential()
model.add(Dense(164, input_shape=(len(train_x[0]),), activation='relu'))
#activates the neurons by introducing non linearity to the model
model.add(Dropout(0.5))
model.add(Dense(82, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(len(train_y[0]), activation='softmax'))
#allows model make prediction based on highest probability

# Compile model. Stochastic gradient descent with Nesterov accelerated gradient gives good results for this model
sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

#fitting and saving the model 
hist = model.fit(np.array(train_x), np.array(train_y), epochs=200, batch_size=5, verbose=1)
model.save('Nutribot_model.h5', hist)

print("model created")






